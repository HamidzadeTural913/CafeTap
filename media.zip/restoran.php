<?php
include"komek.php";
?>

<div class="container" >

<?php



if(isset($_POST['axtar']) && !empty($_POST['sorgu']))
{$axtar = " WHERE (ad LIKE '%".$_POST['sorgu']."%' OR unvan LIKE '%".$_POST['sorgu']."%')";}
else
{$axtar = "";}


if(isset($_POST['d']))
{
	if(empty($_POST['ad'])){unset($_POST['ad']);} else{$ad = trim($_POST['ad']);}
    if(empty($_POST['unvan'])){unset($_POST['unvan']);} else{$unvan = trim($_POST['unvan']);}
    if(empty($_POST['tel'])){unset($_POST['tel']);} else{$tel = trim($_POST['tel']);}
    if(empty($_POST['sitel'])){unset($_POST['sitel']);} else{$sitel = trim($_POST['sitel']);}
    if(empty($_POST['haqqinda'])){unset($_POST['haqqinda']);} else{$haqqinda = trim($_POST['haqqinda']);}


    if(isset($_POST['canli']))
    {$canli=1;}
    else
    {$canli=0;}

    if(isset($_POST['biznes']))
    {$biznes=1;}
    else
    {$biznes=0;}

    if(isset($_POST['catdirilma']))
    {$catdirilma=1;}
    else
    {$catdirilma=0;}

    if(isset($_POST['banket']))
    {$banket=1;}
    else
    {$banket=0;}

    if(isset($_POST['kabinet']))
    {$kabinet=1;}
    else
    {$kabinet=0;}

    if(isset($_POST['milli']))
    {$milli=1;}
    else
    {$milli=0;}

    if(isset($_POST['ecnebi']))
    {$ecnebi=1;}
    else
    {$ecnebi=0;}

    if(isset($_POST['doner']))
    {$doner=1;}
    else
    {$doner=0;}
    
    if(isset($_POST['susi']))
    {$susi=1;}
    else
    {$susi=0;}
    
    if(isset($_POST['ps']))
    {$ps=1;}
    else
    {$ps=0;}

    if(isset($_POST['club']))
    {$club=1;}
    else
    {$club=0;}

    if(isset($_POST['postter']))
    {$postter=1;}
    else
    {$postter=0;}

    if(isset($_POST['qelyan']))
    {$qelyan=1;}
    else
    {$qelyan=0;}

    if(isset($_POST['karaoke']))
    {$karaoke=1;}
    else
    {$karaoke=0;}

    if(isset($_POST['sutka']))
    {$sutka=1;}
    else
    {$sutka=0;}
    

    
	

	if(isset($ad) && isset($unvan) && isset($tel) && isset($sitel) && isset($haqqinda))
		{
				$yoxla = mysqli_query($con,"SELECT * FROM restoran  WHERE ad='".$ad."' AND  unvan='".$unvan."' AND  tel='".$tel."'");


				if (mysqli_num_rows($yoxla)==0)
				 {
				 	include"upload.php";
				 	include"upload2.php";
				 	include"upload3.php";
					
					if(!isset($error))
					{
			          $daxilet = mysqli_query($con,"INSERT INTO restoran(ad,unvan,tel,sitel,haqqinda,canli,biznes,catdirilma,banket,kabinet,milli,ecnebi,doner,susi,ps,club,postter,qelyan,sutka,foto,foto_masa,foto_zal,tarix) 
					VALUES('".$ad."','".$unvan."','".$tel."','".$sitel."','".$haqqinda."','".$canli."','".$biznes."','".$catdirilma."','".$banket."','".$kabinet."','".$milli."','".$ecnebi."','".$doner."','".$susi."','".$ps."','".$club."','".$postter."','".$qelyan."','".$karaoke."','".$sutka."','".$foto_unvan."','".$foto_masa."','".$foto_zal."','".$tarix."')");

						
					}

                      
                    
                    
                   

					if($daxilet==true)
					{echo'<div class="alert alert-success" role="alert">Restoran uğurla əlavə edildi</div>';}
				    else
				    {echo'<div class="alert alert-danger" role="alert">Restoranı əlavə etmək olmadı</div>';}

				}

		
		}
	    else
		{echo'<div class="alert alert-danger">Lütfən məlumatları tam daxil edin</div>';}

}


if(isset($_POST['sil']))
{
	echo'
	<div class="alert alert-warning" role="alert">
	<form method="post">
	
	<b>'.$_POST['ad'].'</b>  restoranını silməyə əminsinizmi?<br>

	<input type="hidden" name="id" value="'.$_POST['id'].'">
	
	<button type="submit" name="he" class="btn btn-success btn-sm">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
</svg>
							</button>

	<button type="submit" name="yox" class="btn btn-danger btn-sm">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
</svg>
							</button>

	</form>
	</div>';
}

if(isset($_POST['he']))
{
	$sil = mysqli_query($con,"DELETE FROM restoran WHERE id='".$_POST['id']."'");

	if($sil==true)
	{echo'<div class="alert alert-success" role="alert">Restoran uğurla silindi</div>';}
	else
	{echo'<div class="alert alert-danger" role="alert">Restoranı silmək mümkün olmadı</div>';}
}

if(isset($_POST['update']))
{
	if(empty($_POST['ad'])){unset($_POST['ad']);} else{$ad = trim($_POST['ad']);}
	if(empty($_POST['unvan'])){unset($_POST['unvan']);} else{$unvan = trim($_POST['unvan']);}
    if(empty($_POST['tel'])){unset($_POST['tel']);} else{$tel = trim($_POST['tel']);}
    if(empty($_POST['sitel'])){unset($_POST['sitel']);} else{$sitel = trim($_POST['sitel']);}
    if(empty($_POST['haqqinda'])){unset($_POST['haqqinda']);} else{$haqqinda = trim($_POST['haqqinda']);}
    
    


		if(isset($ad) && isset($unvan) && isset($tel) && isset($sitel) && isset($haqqinda))
		{
			$yoxla = mysqli_query($con,"SELECT * FROM restoran  WHERE ad='".$ad."' AND  unvan='".$unvan."' AND  tel='".$tel."' AND id!='".$_POST['id']."'");

			if(mysqli_num_rows($yoxla)==0)
			{
                 
                if(empty($_POST['canli'])){$canli=0;} else{$canli=1;}
                if(empty($_POST['biznes'])){$biznes=0;} else{$biznes=1;}
                if(empty($_POST['catdirilma'])){$catdirilma=0;} else{$catdirilma=1;}
                if(empty($_POST['banket'])){$banket=0;} else{$banket=1;}
                if(empty($_POST['kabinet'])){$kabinet=0;} else{$kabinet=1;}
                if(empty($_POST['milli'])){$milli=0;} else{$milli=1;}
                if(empty($_POST['ecnebi'])){$ecnebi=0;} else{$ecnebi=1;}
                if(empty($_POST['doner'])){$doner=0;} else{$doner=1;}
                if(empty($_POST['susi'])){$susi=0;} else{$susi=1;}
                if(empty($_POST['ps'])){$ps=0;} else{$ps=1;}
                if(empty($_POST['club'])){$club=0;} else{$club=1;}
                if(empty($_POST['postter'])){$postter=0;} else{$postter=1;}
                if(empty($_POST['qelyan'])){$qelyan=0;} else{$qelyan=1;}
                if(empty($_POST['karaoke'])){$karaoke=0;} else{$karaoke=1;}
                if(empty($_POST['sutka'])){$sutka=0;} else{$sutka=1;}
				
				if($_FILES['foto']['size']<100)
				{$foto_unvan = $_POST['cari_foto1'];}
				else
				{include"upload.php";}


				if($_FILES['foto_masa']['size']<100)
				{$foto_unvan2 = $_POST['cari_foto2'];} 
				else			
                {include"upload2.php";}

                if($_FILES['foto_zal']['size']<100)
				{$foto_unvan3 = $_POST['cari_foto3'];} 
				else			
                {include"upload3.php";}


				if(!isset($error))
				{
					$yenile = mysqli_query($con,"UPDATE restoran SET 
						ad='".$ad."',
						unvan='".$unvan."',
						tel='".$tel."',
						sitel='".$sitel."',
						haqqinda='".$haqqinda."',
						canli='".$canli."',
						biznes='".$biznes."',
						catdirilma='".$catdirilma."',
						banket='".$banket."',
						kabinet='".$kabinet."',
						milli='".$milli."',
						doner='".$doner."',
						susi='".$susi."',
						ecnebi='".$ecnebi."',
						ps='".$ps."',
						club='".$club."',
						postter='".$postter."',
						qelyan='".$qelyan."',
						karaoke='".$karaoke."',
						sutka='".$sutka."',

						foto='".$foto_unvan."',
						foto_masa='".$foto_masa."',
						foto_zal='".$foto_zal."',
						tarix= '".$tarix."' 
						WHERE id ='".$_POST['id']."'");

					
					

					

					if($yenile==true)
					{echo'<div class="alert alert-success" role="alert">Restoran uğurla yeniləndi</div>';}
					else
					{echo'<div class="alert alert-danger" role="alert">Restoranı yeniləmək mümkün olmadı</div>';}
				}
			}
			else
			{echo'<div class="alert alert-danger" role="alert">Restoran artıq mövcuddur</div>';}
	}
	else
	{echo'Lütfən məlumatları tam doldurun<br>';}
}





if(isset($_POST['edit']))
{
	
	$sec = mysqli_query($con,"SELECT * FROM restoran WHERE id='".$_POST['id']."'");
	$info = mysqli_fetch_array($sec);

	if($info['canli']==1){$canli='checked';} else{$canli='';}
	if($info['biznes']==1){$biznes='checked';} else{$biznes='';}
	if($info['catdirilma']==1){$catdirilma='checked';} else{$catdirilma='';}
	if($info['banket']==1){$banket='banket';} else{$banket='';}
	if($info['kabinet']==1){$kabinet='checked';} else{$kabinet='';}
	if($info['milli']==1){$milli='checked';} else{$milli='';}
	if($info['ecnebi']==1){$ecnebi='checked';} else{$ecnebi='';}
	if($info['doner']==1){$doner='checked';} else{$doner='';}
	if($info['susi']==1){$susi='checked';} else{$susi='';}
	if($info['ps']==1){$ps='checked';} else{$ps='';}
	if($info['club']==1){$club='checked';} else{$club='';}
	if($info['postter']==1){$postter='checked';} else{$postter='';}
	if($info['qelyan']==1){$qelyan='checked';} else{$qelyan='';}
	if($info['karaoke']==1){$karaoke='checked';} else{$karaoke='';}
	if($info['sutka']==1){$sutka='checked';} else{$sutka='';}



	
	echo'
	<div class="alert alert-dark" role="alert">
		<form method="post" enctype="multipart/form-data">
			Restoranın adı:<br>
			<input type="text" name="ad" class="form-control" autocomplete="off" value="'.$info['ad'].'"><br>
			Ünvan:<br>
			<input type="text" name="unvan" class="form-control" autocomplete="off" value="'.$info['unvan'].'"><br>
			Əlaqə nömrəsi:<br>
			<input type="text" name="tel" class="form-control" autocomplete="off" value="'.$info['tel'].'"><br>
			Sifariş nömrəsi:<br>
			<input type="text" name="sitel" class="form-control" autocomplete="off" value="'.$info['sitel'].'"><br>
            Haqqımızda:<br>
			<textarea cols="24" rows="5" name="haqqinda" class="form-control" autocomplete="off">'.$info['haqqinda'].'</textarea>

			Canlı musiqi
            <input type="checkbox" '.$canli.' name="canli" value="1"><br><br>
            Business Lunch
            <input type="checkbox" '.$biznes.' name="biznes" value="1"><br><br>
            Çatdırılma
            <input type="checkbox" '.$catdirilma.' name="catdirilma" value="1"><br><br>
            Banket
            <input type="checkbox" '.$banket.' name="banket" value="1"><br><br>
            Kabinet
            <input type="checkbox" '.$kabinet.' name="kabinet" value="1"><br><br>
            Milli
            <input type="checkbox" '.$milli.' name="milli" value="1"><br><br>
            Əcnəbi
            <input type="checkbox" '.$ecnebi.' name="ecnebi" value="1"><br><br>
            Dönər
            <input type="checkbox" '.$doner.' name="doner" value="1"><br><br>
            Suşi
            <input type="checkbox" '.$susi.' name="susi" value="1"><br><br>
            Play-Station 3/4
            <input type="checkbox" '.$ps.' name="ps" value="1"><br><br>
            Club
            <input type="checkbox" '.$club.' name="club" value="1"><br><br>
            Post-terminal
            <input type="checkbox" '.$postter.' name="postter" value="1"><br><br>
            Qəlyan
            <input type="checkbox" '.$qelyan.' name="qelyan" value="1"><br><br>
            Karaoke
            <input type="checkbox" '.$karaoke.' name="karaoke" value="1"><br><br>
            7/24 açıq
            <input type="checkbox" '.$sutka.' name="sutka" value="1"><br><br>



			<input type="hidden" name="id" value="'.$info['id'].'">
			<input type="hidden" name="cari_foto1" value="'.$info['foto'].'">
			<input type="hidden" name="cari_foto2" value="'.$info['foto_masa'].'">
			<input type="hidden" name="cari_foto3" value="'.$info['foto_zal'].'">
			Foto:<br>
			<img style="width:80px; height:60px;" src="'.$info['foto'].'"><br>
			<input type="file" name="foto" class="form-control"><br><br>
			Masa fotosu:<br>
			<img style="width:80px; height:60px;" src="'.$info['foto_masa'].'"><br>
			<input type="file" name="foto_masa" class="form-control"><br><br>
			Zal fotosu:<br>
			<img style="width:80px; height:60px;" src="'.$info['foto_zal'].'"><br>
			<input type="file" name="foto_zal" class="form-control"><br><br>
			

	<button type="submit" name="update" class="btn btn-success">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-check-circle-fill" viewBox="0 0 16 16">
  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zm-3.97-3.03a.75.75 0 0 0-1.08.022L7.477 9.417 5.384 7.323a.75.75 0 0 0-1.06 1.06L6.97 11.03a.75.75 0 0 0 1.079-.02l3.992-4.99a.75.75 0 0 0-.01-1.05z"/>
</svg>
							</button>

	<button type="submit" name="yox" class="btn btn-danger">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle-fill" viewBox="0 0 16 16">
  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM5.354 4.646a.5.5 0 1 0-.708.708L7.293 8l-2.647 2.646a.5.5 0 0 0 .708.708L8 8.707l2.646 2.647a.5.5 0 0 0 .708-.708L8.707 8l2.647-2.646a.5.5 0 0 0-.708-.708L8 7.293 5.354 4.646z"/>
</svg>
							</button>



		</form>
	</div>';


}

if(!isset($_POST['edit']))
{
	echo'
	<div class="alert alert-dark" role="alert">
		<form method="post" enctype="multipart/form-data">
			Restoranın adı:<br>
			<input type="text" name="ad" class="form-control" autocomplete="off"><br>
			Ünvan:<br>
			<input type="text" name="unvan" class="form-control" autocomplete="off"><br>
			Əlaqə nömrəsi:<br>
			<input type="text" name="tel" class="form-control" autocomplete="off"><br>
			Sifariş nömrəsi:<br>
			<input type="text" name="sitel" class="form-control" autocomplete="off" ><br>
            Haqqımızda:<br>
			<textarea cols="48" rows="5" name="haqqinda" class="form-control" autocomplete="off"></textarea><br>
            <input type="checkbox" name="canli" value="1">
            Canlı musiqi
            <input type="checkbox" name="biznes" value="1">
			Business Lunch
		    <input type="checkbox" name="catdirilma" value="1">
		    Çatdırılma		    
		    <input type="checkbox" name="banket" value="1">
		    Banket zalı
		    <input type="checkbox" name="kabinet" value="1">
		    Kabinet
		    <input type="checkbox" name="milli" value="1">
		    Milli mətbəx
		    <input type="checkbox" name="ecnebi" value="1">
		    Əcnəbi mətbəx
		    <input type="checkbox" name="doner" value="1">
		    Dönər
		    <input type="checkbox" name="susi" value="1">
		    Suşi
		    <input type="checkbox" name="ps" value="1">
		    Playstation 3/4<br><br>
		    <input type="checkbox" name="club" value="1">
		    Club
		    <input type="checkbox" name="postter" value="1">
		    Post-terminal
		    <input type="checkbox" name="qelyan" value="1">
		    Qəlyan
		    <input type="checkbox" name="karaoke" value="1">
		    Karaoke
		    <input type="checkbox" name="sutka" value="1">
		    7/24 açıq<br><br>

		    Restoranın görünüşü:<br>
			<input type="file" name="foto" class="form-control">
			Masa görünüşü:<br>
            <input type="file" name="foto_masa" class="form-control">
            Zal görünüşü:<br>
            <input type="file" name="foto_zal" class="form-control"><br><br>
            

            <button type="submit" name="d" class="btn btn-success">
			<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus-circle-fill" viewBox="0 0 16 16">
	  <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.5 4.5a.5.5 0 0 0-1 0v3h-3a.5.5 0 0 0 0 1h3v3a.5.5 0 0 0 1 0v-3h3a.5.5 0 0 0 0-1h-3v-3z"/>
	</svg>
			</button>
		</form>
	</div>';

}

		
		


?>
 

  </form>

  <?php
 
  $sec = mysqli_query($con,'SELECT * FROM restoran  '.$axtar.' ORDER BY id DESC');
  $info = mysqli_fetch_array($sec);
  $say = mysqli_num_rows($sec);

if($say>0)
{
  ?>


  <div class="alert alert-info" role="alert">Bazada <b><?=$say ?></b> Restoran var</div>

  <table class="table table-dark" id="cedvel">
  	<thead>
  		<th>#</th>
  		<th>Foto</th>
  		<th>Masa fotosu</th>
  		<th>Zal fotosu</th>
  		<th>Restoranın adı</th>
  		<th>Ünvan</th>
  		<th>Əlaqə nömrəsi</th>
   		<th>Tarix</th>
   		<th></th>
  	</thead>
  
    <tbody>
    	
       <?php

          $i = 0;

          do          
           {
           	
           	$i++;

           echo'<tr>';
               echo'<td>'.$i.'</td>';
               echo'<td><img style="width:80px; height:60px;" src="'.$info['foto'].'"></td>';
               echo'<td><img style="width:80px; height:60px;" src="'.$info['foto_masa'].'"></td>';
               echo'<td><img style="width:80px; height:60px;" src="'.$info['foto_zal'].'"></td>';
               echo'<td>'.$info['ad'].'</td>';
               echo'<td>'.$info['unvan'].'</td>';
               echo'<td>'.$info['tel'].'</td>';             
               echo'<td>'.$info['tarix'].'</td>';
               echo'<td>

                    <form method="post">
                    <input type="hidden" name="id" value="'.$info['id'].'">
					<input type="hidden" name="ad" value="'.$info['ad'].'">
					<input type="hidden" name="unvan" value="'.$info['unvan'].'">
					<input type="hidden" name="haqqinda" value="'.$info['haqqinda'].'">
					<input type="hidden" name="tel" value="'.$info['tel'].'">
					<input type="hidden" name="tel" value="'.$info['sitel'].'">
					

					<button type="submit" name="edit" class="btn btn-success"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                    <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                    <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                    </svg>
                    </button>
					
					
					<button type="submit" name="sil" class="btn btn-danger"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
  <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5zm3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0V6z"/>
  <path fill-rule="evenodd" d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1v1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z"/>
</svg>
					</button>
					</form>

               </td>';

           echo'</tr>';



           }

           while($info = mysqli_fetch_array($sec));
            
           ?>

    </tbody>

  </table>

<?php 
}
else
{echo'<div class="alert alert-warning" role="alert">Bazada heç bir restoran mövcud deyldir</div>';} 


?>

</div>
