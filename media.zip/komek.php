<?php

$con = mysqli_connect('localhost','restoran','tb2021','restoran');
$tarix = date('Y-m-d H:i:s');

?>
<br><br><br><br>


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.min.js" integrity="sha384-+YQ4JLhjyBLPDQt//I+STsc9iw4uQqACwlvpslubQzn4u2UU2UFM80nGisd026JF" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>



<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <a class="navbar-brand" href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-house-fill" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6zm5-.793V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
  <path fill-rule="evenodd" d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z"/>
</svg></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">

        <li class="nav-item active">      
        <a class="nav-link" href="restoran.php">Restoran<span class="sr-only"></span></a>
      </li>

      <li class="nav-item active">
        <a class="nav-link" href="menu.php">Menu</a>
      </li>

      <li class="nav-item active">
        <a class="nav-link dropdown-toggle" href="yemek.php">Yemek</a>
    </li>
        
        
    
      <li class="nav-item active">
        <a class="nav-link disabled" href="#">Disabled</a>
      </li>
    </ul>
      <form class="form-inline my-2 my-lg-0" action="#cedvel" method="post">
      <input class="form-control mr-sm-2" type="text" placeholder="Axtar" autocomplete="off" name="sorgu" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="axtar">Axtar</button> &nbsp;
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="all">Hamısı</button>
    </form>
  </div>
</nav>